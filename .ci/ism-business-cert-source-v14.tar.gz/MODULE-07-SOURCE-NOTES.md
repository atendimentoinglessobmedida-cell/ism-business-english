# Module 07 — source-grounded implementation
Source: corrected transcription pages 58–67 and editorial audit.

Preserved sequence: Audience & Purpose; Core Message; Three-Part Structure; Signposting;
Timing & Agenda; Match Your Language to the Audience; Presentation Planning Challenge;
Choosing Visual Support; Review Quiz.

Editorial correction applied from the audit:
MATCH YOUR LANGUAGE TO THE AUDIENCE / ADEQUE SUA LINGUAGEM AO PÚBLICO.

Next canonical chapter: Chapter 08 — Opening a Presentation.
