# Supabase, Access Control & Persistence Hardening

## Commercial access rule
Only `course_access.status = active` grants access to the training.
`payment_pending`, `expired`, `canceled`, `suspended` and missing access block the course while preserving the user's data.

A `valid_until` date in the past also blocks access even when the stored status is `active`.

## Middleware
Protected training routes now require:
1. authenticated Supabase user
2. active course access
3. non-expired validity date

Protected areas include Home, Journey, Practice, Simulations, Toolkit, Profile, Course, Progress, Meeting Builder, Presentation Builder and Live Meeting.

## Data preservation
No progress is deleted when access becomes inactive.

## New persistence tables
- `xp_ledger`
- `user_achievements`
- `meeting_plans`
- `presentation_plans`

All four have RLS restricting rows to the authenticated user.

## Sync layer
`ProgressSync` runs in the authenticated main layout and:
- hydrates My Work from Supabase
- uploads local course progress
- uploads lesson results
- mirrors XP awards
- mirrors achievements
- uploads meeting plans
- uploads presentation plans
- retries when the browser returns online

The app remains local-first, so temporary network failure does not erase learning activity.

## Security fixes
- Login `next` redirect is sanitized to internal paths only.
- Course access no longer treats `payment_pending` or `canceled` as active.
- Access-required screen no longer contains a fake reactivation action.
- RLS definitions were added for the new persistence tables.

## Live-environment verification still required
This package includes schema and migration definitions, but they have not been executed against the user's production Supabase project in this environment.

Before release:
1. apply the migration in staging
2. verify all RLS policies with two test accounts
3. verify active / payment_pending / expired / canceled states
4. verify local -> cloud sync and second-device hydration
5. run clean production build
